﻿namespace dbms_project
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dONORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLLDONORDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHBLOODDONORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOCATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bLOODGROUPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNCREASEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dECREASEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEDONORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dONORToolStripMenuItem,
            this.sEARCHBLOODDONORToolStripMenuItem,
            this.sTOCKToolStripMenuItem,
            this.dELETEDONORToolStripMenuItem,
            this.lOGOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1744, 97);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // dONORToolStripMenuItem
            // 
            this.dONORToolStripMenuItem.AutoSize = false;
            this.dONORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDDETAILSToolStripMenuItem,
            this.uPDATEDETAILSToolStripMenuItem,
            this.aLLDONORDETAILSToolStripMenuItem});
            this.dONORToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dONORToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("dONORToolStripMenuItem.Image")));
            this.dONORToolStripMenuItem.Name = "dONORToolStripMenuItem";
            this.dONORToolStripMenuItem.Size = new System.Drawing.Size(150, 93);
            this.dONORToolStripMenuItem.Text = "DONOR";
            // 
            // aDDDETAILSToolStripMenuItem
            // 
            this.aDDDETAILSToolStripMenuItem.Name = "aDDDETAILSToolStripMenuItem";
            this.aDDDETAILSToolStripMenuItem.Size = new System.Drawing.Size(267, 32);
            this.aDDDETAILSToolStripMenuItem.Text = "ADD DETAILS";
            this.aDDDETAILSToolStripMenuItem.Click += new System.EventHandler(this.aDDDETAILSToolStripMenuItem_Click);
            // 
            // uPDATEDETAILSToolStripMenuItem
            // 
            this.uPDATEDETAILSToolStripMenuItem.Name = "uPDATEDETAILSToolStripMenuItem";
            this.uPDATEDETAILSToolStripMenuItem.Size = new System.Drawing.Size(267, 32);
            this.uPDATEDETAILSToolStripMenuItem.Text = "UPDATE DETAILS";
            this.uPDATEDETAILSToolStripMenuItem.Click += new System.EventHandler(this.uPDATEDETAILSToolStripMenuItem_Click);
            // 
            // aLLDONORDETAILSToolStripMenuItem
            // 
            this.aLLDONORDETAILSToolStripMenuItem.Name = "aLLDONORDETAILSToolStripMenuItem";
            this.aLLDONORDETAILSToolStripMenuItem.Size = new System.Drawing.Size(267, 32);
            this.aLLDONORDETAILSToolStripMenuItem.Text = "ALL DONOR DETAILS";
            this.aLLDONORDETAILSToolStripMenuItem.Click += new System.EventHandler(this.aLLDONORDETAILSToolStripMenuItem_Click);
            // 
            // sEARCHBLOODDONORToolStripMenuItem
            // 
            this.sEARCHBLOODDONORToolStripMenuItem.AutoSize = false;
            this.sEARCHBLOODDONORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lOCATIONToolStripMenuItem,
            this.bLOODGROUPToolStripMenuItem});
            this.sEARCHBLOODDONORToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sEARCHBLOODDONORToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHBLOODDONORToolStripMenuItem.Image")));
            this.sEARCHBLOODDONORToolStripMenuItem.Name = "sEARCHBLOODDONORToolStripMenuItem";
            this.sEARCHBLOODDONORToolStripMenuItem.Size = new System.Drawing.Size(250, 93);
            this.sEARCHBLOODDONORToolStripMenuItem.Text = "SEARCH BLOOD DONOR";
            // 
            // lOCATIONToolStripMenuItem
            // 
            this.lOCATIONToolStripMenuItem.Name = "lOCATIONToolStripMenuItem";
            this.lOCATIONToolStripMenuItem.Size = new System.Drawing.Size(218, 32);
            this.lOCATIONToolStripMenuItem.Text = "LOCATION";
            this.lOCATIONToolStripMenuItem.Click += new System.EventHandler(this.lOCATIONToolStripMenuItem_Click);
            // 
            // bLOODGROUPToolStripMenuItem
            // 
            this.bLOODGROUPToolStripMenuItem.Name = "bLOODGROUPToolStripMenuItem";
            this.bLOODGROUPToolStripMenuItem.Size = new System.Drawing.Size(218, 32);
            this.bLOODGROUPToolStripMenuItem.Text = "BLOOD GROUP";
            // 
            // sTOCKToolStripMenuItem
            // 
            this.sTOCKToolStripMenuItem.AutoSize = false;
            this.sTOCKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNCREASEToolStripMenuItem,
            this.dECREASEToolStripMenuItem,
            this.dETAILSToolStripMenuItem});
            this.sTOCKToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sTOCKToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sTOCKToolStripMenuItem.Image")));
            this.sTOCKToolStripMenuItem.Name = "sTOCKToolStripMenuItem";
            this.sTOCKToolStripMenuItem.Size = new System.Drawing.Size(110, 93);
            this.sTOCKToolStripMenuItem.Text = "STOCK";
            // 
            // iNCREASEToolStripMenuItem
            // 
            this.iNCREASEToolStripMenuItem.Name = "iNCREASEToolStripMenuItem";
            this.iNCREASEToolStripMenuItem.Size = new System.Drawing.Size(176, 32);
            this.iNCREASEToolStripMenuItem.Text = "INCREASE";
            this.iNCREASEToolStripMenuItem.Click += new System.EventHandler(this.iNCREASEToolStripMenuItem_Click);
            // 
            // dECREASEToolStripMenuItem
            // 
            this.dECREASEToolStripMenuItem.Name = "dECREASEToolStripMenuItem";
            this.dECREASEToolStripMenuItem.Size = new System.Drawing.Size(176, 32);
            this.dECREASEToolStripMenuItem.Text = "DECREASE";
            // 
            // dETAILSToolStripMenuItem
            // 
            this.dETAILSToolStripMenuItem.Name = "dETAILSToolStripMenuItem";
            this.dETAILSToolStripMenuItem.Size = new System.Drawing.Size(176, 32);
            this.dETAILSToolStripMenuItem.Text = "DETAILS";
            // 
            // dELETEDONORToolStripMenuItem
            // 
            this.dELETEDONORToolStripMenuItem.AutoSize = false;
            this.dELETEDONORToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dELETEDONORToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("dELETEDONORToolStripMenuItem.Image")));
            this.dELETEDONORToolStripMenuItem.Name = "dELETEDONORToolStripMenuItem";
            this.dELETEDONORToolStripMenuItem.Size = new System.Drawing.Size(180, 93);
            this.dELETEDONORToolStripMenuItem.Text = "DELETE DONOR";
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.AutoSize = false;
            this.lOGOUTToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOGOUTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("lOGOUTToolStripMenuItem.Image")));
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(120, 93);
            this.lOGOUTToolStripMenuItem.Text = "LOG OUT";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click);
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1744, 889);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dashboard";
            this.Load += new System.EventHandler(this.dashboard_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dONORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPDATEDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLLDONORDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHBLOODDONORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOCATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bLOODGROUPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOCKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNCREASEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dECREASEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEDONORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
    }
}