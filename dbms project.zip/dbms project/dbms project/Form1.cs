﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbms_project
{
    public partial class Form1 : Form
    {
        function fn = new function();
        public static int id;
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
           String username = txtusername.Text;
            String password = txtpassword.Text;
            string query_1 ="select M_id from BB_Manager where mName = '"+username+"' ";
            DataSet ds_1 = fn.getData(query_1);
            int count_1 = int.Parse(ds_1.Tables[0].Rows[0][0].ToString());
            id = count_1;

           /* if (txtusername.Text == "saral" && txtpassword.Text == "pass")
            {
                dashboard db = new dashboard();
                db.Show();
            }
            else
            {
                MessageBox.Show("enter Valid username or password");
            }*/
            string query = "select count(M_id) from BB_Manager where mName='"+username+"' and m_phNo='"+password+"' ";
            DataSet ds = fn.getData(query);
            int count = int.Parse(ds.Tables[0].Rows[0][0].ToString());
            if (count > 0)
            {
                dashboard db = new dashboard();
                db.Show();
            }
            else
            {
                MessageBox.Show("enter Valid username or password");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                btnlogin.Enabled = true;
            }
            else
            {
                btnlogin.Enabled = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnlogin.Enabled = false;
        }
    }
}
