﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbms_project
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1();
            fm.Show();
            this.Hide();
        }

        private void aDDDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewdonor and = new AddNewdonor();
            and.Show();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {

        }

        private void uPDATEDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updatedonor ud = new updatedonor();
            ud.Show();
        }

        private void aLLDONORDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllDonorDetails add = new AllDonorDetails();
            add.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void lOCATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void iNCREASEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stock_increase si = new stock_increase();
            si.Show();
        }
    }
}
