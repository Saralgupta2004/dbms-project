﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbms_project
{
    public partial class AddNewdonor : Form
    {
        function fn = new function();
        public AddNewdonor()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddNewdonor_Load(object sender, EventArgs e)
        {
            string query = "select max(id) from donor";
            DataSet ds = fn.getData(query);
            int count = int.Parse(ds.Tables[0].Rows[0][0].ToString());
            labelNewID.Text = (count+1).ToString();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text != "" && textBox_father.Text != "" && textBox_mother.Text != "" && textBox_mobileno.Text != "" && textBox_city.Text != "" && comboBox_bloodgrp.Text != "" && comboBox_gender.Text != "" && dateTimePicker_dob.Text != "" && textBox_email.Text != "" && textBox_address.Text != "")
            {
                String donorname = textBox_name.Text;
                String fathername = textBox_father.Text;
                String mothername = textBox_mother.Text;
                String dob = dateTimePicker_dob.Text;
                Int64 mobileno = Int64.Parse(textBox_mobileno.Text);
                String gender = comboBox_gender.Text;
                String email = textBox_email.Text;
                String bloodgroup = comboBox_bloodgrp.Text;
                String city = textBox_city.Text;
                String donoraddress = textBox_address.Text;

                String query ="insert into donor values ('"+donorname+"','"+fathername+"','"+mothername+"','"+dob+"','"+mobileno+"','"+gender+"','"+email+"','"+bloodgroup+"','"+city+"','"+donoraddress+"')";
                fn.setdata(query);
            }
            else
            {
                MessageBox.Show("fill all fields","error",MessageBoxButtons.OK,MessageBoxIcon.Information); 
            }
        }
    }
}
