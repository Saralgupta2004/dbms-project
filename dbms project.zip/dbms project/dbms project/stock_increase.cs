﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbms_project
{
    public partial class stock_increase : Form
    {
        function fn = new function();
        public stock_increase()
        {
            InitializeComponent();
        }

        private void stock_increase_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "update hospital_2 set quantity ='" + textBox2.Text + "' where bld_grp='" + comboBox1 + "' and hosp_id = (select hosp_id from hospital where m_id='" + Form1.id + "') ";
            fn.setdata(query);
        }
    }
}
