﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbms_project
{
    public partial class updatedonor : Form
    {
        function fn = new function();
        public updatedonor()
        {
            InitializeComponent();
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txt_id.Text.ToString());
            String query = "select * from donor where id =" + id + "";
            DataSet ds = fn.getData(query);
            if (ds.Tables[0].Rows.Count != 0)
            {
                txt_name.Text = ds.Tables[0].Rows[0][1].ToString();
                txt_mother.Text = ds.Tables[0].Rows[0][3].ToString();
                txt_father.Text = ds.Tables[0].Rows[0][2].ToString();
                txt_email.Text = ds.Tables[0].Rows[0][7].ToString();
                txt_mobile.Text = ds.Tables[0].Rows[0][5].ToString();
                comboblood.Text = ds.Tables[0].Rows[0][8].ToString();
                combogender.Text = ds.Tables[0].Rows[0][6].ToString();
                txt_date.Text = ds.Tables[0].Rows[0][4].ToString();
                txt_city.Text = ds.Tables[0].Rows[0][9].ToString();
                txt_address.Text = ds.Tables[0].Rows[0][10].ToString();



            }
            else
            {
                MessageBox.Show("invalid id ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void button_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_reset_Click(object sender, EventArgs e)
        {
            txt_id.Clear();


        }

        private void button_save_Click(object sender, EventArgs e)
        {
            String query = "update donor set donorname='" + txt_name.Text + "',fathername='" + txt_father + "',mothername='" + txt_mother.Text + "',dob='" + txt_date.Text + "',mobileno='" + txt_mobile.Text + "',gender='" + combogender.Text + "',email='" + txt_email.Text + "',bloodgroup='" + comboblood.Text + "',city='" + txt_city.Text + "',donoraddress='" + txt_address.Text + "' ";
            fn.setdata(query);
            updatedonor_Load(this, null);
    
        }

        private void txt_id_TextChanged(object sender, EventArgs e)
        {
            if (txt_id.Text == "")
            {
                txt_name.Clear();
                txt_mother.Clear();
                txt_mobile.Clear();
                txt_father.Clear();
                txt_email.Clear();
                txt_date.ResetText();
                txt_city.Clear();
                txt_address.Clear();
                comboblood.ResetText();
                combogender.ResetText();

            }

        }

        private void updatedonor_Load(object sender, EventArgs e)
        {
            txt_id.Clear();
        }
    }
}
